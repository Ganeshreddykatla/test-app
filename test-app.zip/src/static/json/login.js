let userDetails = {
  userId: "ganesh.reddy@sekel.tech",
  password: "12345678",
};

export default userDetails;
